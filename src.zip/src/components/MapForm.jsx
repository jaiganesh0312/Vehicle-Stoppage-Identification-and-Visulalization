import React from 'react';
import Input from './Input.jsx';


const MapForm = ({ threshold, handleInputChange, handleInputBlur, inputHasError, handleSubmit, handleFileUpload}) => (
    <form onSubmit={handleSubmit} className="flex-1 shadow-xl p-4">
    <Input 
        label="Upload Excel File"
        id="file-upload"
        type="file"
        name="file-upload"
        onChange = {handleFileUpload}
    />
    
    <Input
      label="Threshold Duration"
      id="threshold"
      type="number"
      name="Threshold duration"
      placeholder="Threshold duration (in minutes)"
      onBlur={handleInputBlur}
      onChange={handleInputChange}
      value={threshold}
      error={inputHasError && 'Please enter a number strictly greater than zero!'}
    />
    <button className="bg-blue-500 text-white rounded-md px-3 py-1 hover:bg-blue-600 active:bg-blue-700">
      Display Stoppages
    </button>
  </form>
);

export default MapForm;
