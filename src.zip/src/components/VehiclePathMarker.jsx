import React from 'react';
import { Marker } from 'react-map-gl';

const VehiclePathMarker = ({ coord, index }) => (
  <Marker key={index} latitude={coord.latitude} longitude={coord.longitude}>
    <div
      style={{
        backgroundColor: 'blue',
        width: '5px',
        height: '5px',
        borderRadius: '50%',
      }}
    />
  </Marker>
);

export default VehiclePathMarker;
