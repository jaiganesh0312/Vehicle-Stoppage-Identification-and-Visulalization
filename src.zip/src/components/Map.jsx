import { Fragment, useState, Suspense } from 'react';
import ReactMapGL, { Source, Layer } from 'react-map-gl';
import * as XLSX from 'xlsx';
import 'mapbox-gl/dist/mapbox-gl.css';


import { identifyStoppages } from '../util/identifyStoppages';
import { useInput } from '../hooks/useInput.js';

import MapForm from './MapForm.jsx';
import StoppageDetails from './StoppageDetails.jsx';
import StoppageMarker from './StoppageMarker.jsx';
import VehiclePathMarker from './VehiclePathMarker.jsx';


const Map = () => {
  const[gpsData, setGpsData] = useState([]);
  const {
    value: threshold,
    handleInputChange,
    handleInputBlur,
    hasError: inputHasError,
  } = useInput(10, (value) => value && value > 0);

  const [viewport, setViewport] = useState({
    latitude: 13.020892517140737,
    longitude: 74.98670449628963,
    zoom: 11,
    width: '100vw',
    height: '100vh',
  });

  const [stoppages, setStoppages] = useState([]);
  const [stoppageIndex, setStoppageIndex] = useState(null);

  const geojson = {
    type: 'FeatureCollection',
    features: [
      {
        type: 'Feature',
        geometry: {
          type: 'LineString',
          coordinates: gpsData.map((coord) => [coord.longitude, coord.latitude]),
        },
      },
    ],
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();

    reader.onload = (event) => {
      const binaryStr = event.target.result;
      const workbook = XLSX.read(binaryStr, { type: 'binary' });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json(worksheet);
      setGpsData(jsonData);
    };
    reader.readAsBinaryString(file);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!inputHasError) {
      setStoppages(identifyStoppages(gpsData, threshold));
      setStoppageIndex(null);
    }
  };

  const handleSelectStoppage = (index) => {
    setStoppageIndex(index);
  };

  return (
    <Fragment>
      <div className="flex gap-6 w-2/3 my-3">
        <MapForm
          threshold={threshold}
          handleInputChange={handleInputChange}
          handleInputBlur={handleInputBlur}
          inputHasError={inputHasError}
          handleSubmit={handleSubmit}
          handleFileUpload={handleFileUpload}
        />
        <StoppageDetails stoppageIndex={stoppageIndex} stoppages={stoppages} />
      </div>
      {gpsData.length > 0 && 
        <div className="map-container">
          <ReactMapGL
            {...viewport}
            mapboxApiAccessToken={process.env.REACT_APP_MAPBOX_TOKEN}
            onViewportChange={setViewport}
            mapStyle="mapbox://styles/mapbox/streets-v11"
          >
            <Source id="route" type="geojson" data={geojson}>
              <Layer
                id="route"
                type="line"
                source="route"
                layout={{
                  'line-join': 'round',
                  'line-cap': 'round',
                }}
                paint={{
                  'line-color': '#888',
                  'line-width': 6,
                }}
              />
            </Source>
            {gpsData.map((coord, index) => (
              <VehiclePathMarker key={index} coord={coord} />
            ))}
            {stoppages.map((coord, index) => (
              <StoppageMarker key={index} coord={coord} index={index} handleSelectStoppage={handleSelectStoppage} />
            ))}
          </ReactMapGL>
        </div>
      }
    </Fragment>
  );
};

export default Map;

