import React from 'react';
import { Marker } from 'react-map-gl';

const StoppageMarker = ({ coord, index, stoppageIndex, handleSelectStoppage }) => (
  <Marker key={index} latitude={coord.latitude} longitude={coord.longitude}>
    <button onClick={() => handleSelectStoppage(index)} disabled={stoppageIndex === index}>
      <img className="h-8 w-8" src="https://img.icons8.com/color/48/000000/marker.png" alt="Marker" />
    </button>
  </Marker>
);

export default StoppageMarker;
