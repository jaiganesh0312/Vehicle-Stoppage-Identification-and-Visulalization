import React from 'react';
import { formatDate } from '../util/formatDate.js';

const StoppageDetails = ({ stoppageIndex, stoppages }) => {
    let content = null;
  if (stoppageIndex === null) {
    content = (
      <>
        <p>Did not select any stoppage</p>
        <p>Click on a stoppage marker (if any visible) to display details!</p>
      </>
    );
  }
  else {
    const stoppage = stoppages[stoppageIndex];
    content = (
        <div>
        <p>Id: {stoppageIndex + 1}</p>
        <p>Arrival Time: {formatDate(stoppage.startTime)}</p>
        <p>Departure Time: {formatDate(stoppage.endTime)}</p>
        <p>Total Duration: {stoppage.duration.toFixed(3)} minutes</p>
        </div>
    );
    }
  return <div className="flex-1 stoppage-details shadow-xl p-4">
    <p className='text-2xl font-semibold text-center mb-3'>Stoppage Details</p>
    {content}
  </div>
  
};

export default StoppageDetails;
