
export const identifyStoppages = (gpsData, threshold) => {
  const stoppages = [];
  let prev_data = null;
  gpsData.forEach((data) => {
    if(data.speed !== 0){
      if(prev_data == null){
        prev_data = data;
      }
      else {
        const timeTaken = (data.eventGeneratedTime - prev_data.eventGeneratedTime)/(1000 * 60);
        const distanceTravelled = data['odometer reading'] -  prev_data['odometer reading'];
        if(distanceTravelled === 0){
          if(timeTaken >= threshold){
              stoppages.push({
              startTime : new Date(prev_data.eventGeneratedTime), 
              endTime : new Date(data.eventGeneratedTime),
              duration: timeTaken,
              latitude: data.latitude,
              longitude: data.longitude
              
            }
            );
          }
        }
        else {
          const duration = timeTaken - ((distanceTravelled * 3)/(data.speed * 50));
          if(duration >= threshold){
            stoppages.push({
              startTime : new Date(data.eventGeneratedTime - duration*60*1000 ), 
              endTime : new Date(data.eventGeneratedTime),
              duration: duration,
              latitude: data.latitude,
              longitude: data.longitude
            }
            );
          }
        }
      }
      prev_data = data;
    }
    
  });
  const data = Date.now();
    const timeTaken = (data.eventGeneratedTime - prev_data.eventGeneratedTime)/(1000 * 60);
    const distanceTravelled = data['odometer reading'] -  prev_data['odometer reading'];
    const duration = timeTaken - ((distanceTravelled * 3)/(data.speed * 50));
          if(duration >= threshold){
            stoppages.push({
              startTime : new Date(data.eventGeneratedTime - duration*60*1000 ), 
              endTime : new Date(data.eventGeneratedTime),
              duration: duration,
              latitude: data.latitude,
              longitude: data.longitude
            }
            );
          }
  return stoppages;
};
  