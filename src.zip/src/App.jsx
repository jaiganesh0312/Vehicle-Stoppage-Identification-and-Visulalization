
import Map from './components/Map';


const App = () => {
  
  return (
    <>
      <p className='text-5xl font-bold text-center mb-3 '>Vehicle Stoppage Identification and Visualizer</p>
      <Map />
    </>
    
  );
};

export default App;
